//booking form script

function validateForm()
{

    var z = document.forms["passengerForm"]["num"].value;
    if(!z.match(/^\d+/))
        {
        alert("Please only enter numeric characters only for your Age! (Allowed input:0-9)")
        }
}
