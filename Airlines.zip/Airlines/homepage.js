
//javascript
console.log("Hi Devika");
